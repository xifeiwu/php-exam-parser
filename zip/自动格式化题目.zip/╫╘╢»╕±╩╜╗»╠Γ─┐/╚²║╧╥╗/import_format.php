<?php
$an=array('A','B','C','D','E');

$idata=strip_tags($_POST['ddd']);

if ($idata)
{

	$aidata=preg_split('/\d+(\.|��|��|��)(?![0-9])/',$idata);
//	print_r($aidata);
	$success_no=0;

//	print_r($aidata);
	//$regstr="/(.*?)(?:\(|��)([a-zA-Z]+)(.*?\n.*)/is";
	$regstr="/(.*?)(?:\(|��)(.*?)(?:\)|��)(.*?\n?.*)/is";

		$i=1;
		foreach ($aidata as $b)
		{
        

				if(preg_match($regstr,$b,$a))
				{
					
//          print_r($a);
//          $i++;
//					echo $i."<br>";
//					exit("ss");
					$tmp = preg_replace($regstr,"\$1()\$3",$a[0]);
					$a[0] = $i.".".$tmp."\n"."�𰸣�".$a[2]."\n";
					$i++;
		
				}
				else
				{
					$newdata.="<font color='red'>{$b}</font>";
				}
				$newdata .= $a[0]."<br/>";
				unset($a);
		
		}

  print nl2br($newdata);

}

if ($idata)
{
	$showhelp=1;	
}
else
{
	$showhelp=0;
}


?>
