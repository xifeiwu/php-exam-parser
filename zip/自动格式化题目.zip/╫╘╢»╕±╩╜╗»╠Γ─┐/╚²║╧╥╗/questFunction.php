<?php 
header("content-Type: text/html; charset=UTF-8");

function imcleantext($keyword)//分录//只能过滤英文字符
{
	$keyword=urlencode($keyword);//将关键字编码
	$keyword=preg_replace("/(%7E|%60|%21|%40|%23|%24|%25|%5E|%26|%27|%2A|%28|%29|%2B|%7C|%5C|%3D|\-|_|%5B|%5D|%7D|%7B|%3B|%22|%3A|%3F|%3E|%3C|%2C|\.|%2F|%A3%BF|%A1%B7|%A1%B6|%A1%A2|%A1%A3|%A3%AC|%7D|%A1%B0|%A3%BA|%A3%BB|%A1%AE|%A1%AF|%A1%B1|%A3%FC|%A3%BD|%A1%AA|%A3%A9|%A3%A8|%A1%AD|%A3%A4|%A1%A4|%A3%A1)+/",'',$keyword);
	$keyword=urldecode($keyword);//将过滤后的关键字解码
	$keyword=str_replace(' ','',$keyword);
	return $keyword;
}

    /**   php全角转半角函数
    * 将一个字串中含有全角的数字字符、字母、空格或'%+-()'字符转换为相应半角字符
    *
    * @access public
    * @param string $str 待转换字串
    *
    * @return string $str 处理后字串
    */

function make_semiangle($str)
{
    $arr = array('０' => '0', '１' => '1', '２' => '2', '３' => '3',
	'４' => '4','５' => '5', '６' => '6', '７' => '7', '８' => '8', 
	'９' => '9',
	'Ａ' => 'A', 'Ｂ' => 'B', 'Ｃ' => 'C', 'Ｄ' => 'D', 'Ｅ' => 'E',
    'Ｆ' => 'F', 'Ｇ' => 'G', 'Ｈ' => 'H', 'Ｉ' => 'I', 'Ｊ' => 'J',
    'Ｋ' => 'K', 'Ｌ' => 'L', 'Ｍ' => 'M', 'Ｎ' => 'N', 'Ｏ' => 'O',
    'Ｐ' => 'P', 'Ｑ' => 'Q', 'Ｒ' => 'R', 'Ｓ' => 'S', 'Ｔ' => 'T',
    'Ｕ' => 'U', 'Ｖ' => 'V', 'Ｗ' => 'W', 'Ｘ' => 'X', 'Ｙ' => 'Y',
    'Ｚ' => 'Z', 'ａ' => 'a', 'ｂ' => 'b', 'ｃ' => 'c', 'ｄ' => 'd',
    'ｅ' => 'e', 'ｆ' => 'f', 'ｇ' => 'g', 'ｈ' => 'h', 'ｉ' => 'i',
    'ｊ' => 'j', 'ｋ' => 'k', 'ｌ' => 'l', 'ｍ' => 'm', 'ｎ' => 'n',
    'ｏ' => 'o', 'ｐ' => 'p', 'ｑ' => 'q', 'ｒ' => 'r', 'ｓ' => 's',
    'ｔ' => 't', 'ｕ' => 'u', 'ｖ' => 'v', 'ｗ' => 'w', 'ｘ' => 'x',
    'ｙ' => 'y', 'ｚ' => 'z',
    '（' => '(', '）' => ')', '〔' => '[', '〕' => ']', '【' => '',
    '】' => '', '〖' => '[', '〗' => ']', '“' => '"', '”' => '"',
    '｛' => '{', '｝' => '}', '《' => '《','》' => '》','％' => '%', 
	'＋' => '+', '—' => '-', '－' => '-', '～' => '-', '：' => ':', 
	'。' => '。', '、' => '、', '，' => ',', '；' => ';', '？' => '?', 
	'！' => '!', '‖' => '|', '’' => '`', '‘' => '`', '｜' => '|', 
	'〃' => '"','　' => ' ');

    return strtr($str, $arr);
 }

/*过滤已经替换过全角的题目标点符号
*/
function filterSymbol($str)
{
	$str=strip_tags($str);//去掉html
	$str=imcleantext($str);//去掉标点符号空格
	$str=preg_replace('|[0-9a-zA-Z/]+|','',$str);//去除字母数字

    $arr = array(
    '('=>'', ')'=>'', '['=>'', ']'=>'', '"'=>'', '"'=>'',
    '{'=>'', '}'=>'', '《'=>'','》'=>'','%'=>'', 
	'+'=>'', '-'=>'', '-'=>'',':'=>'', 
	'。'=>'', '、'=>'', ','=>'', ';'=>'', '?'=>'', 
	'!'=>'', '|'=>'', '`'=>'', '`'=>'', '|'=>'',' '=>'','.'=>'');

    return strtr($str, $arr);
 }


function cloze_format($str)//填空题答案格式化
{
	$str=str_check($str);
    $arr = array('——' => '-','　' => '',' '=>'',' '=>'',':'=>',');//空格都去掉

    return strtr($str, $arr);
 }

 function str_check($k)
{
	//全角替换半角  
	$k=make_semiangle($k);

	// 首先去掉头尾空格
	$k = trim($k);
	$k = preg_replace('/\'/', '‘', $k);//'引起冲突
	// 接着去掉两个空格以上的
	$k = preg_replace('/\s(?=\s)/', '', $k);
	// 最后将非空格替换为一个空格
	$k = preg_replace('/[\n\r\t]/', ' ', $k);
	//去掉两个空格以上的
	$k=preg_replace('/\s{2,}|　/','',$k);//有效

	$k=str_replace("( )。","( )",$k);
	$k=str_replace("。( )","( )",$k);
	$k=str_replace("( ).","( )",$k);
	$k=str_replace("()","( )",$k);//中间替换前面
	$k=str_replace(".( )","( )",$k);//中间替换前面	
	//$k = preg_replace('/\xa3([\xa1-\xfe])/e', 'chr(ord(\1)-0x80)', $k); //遇到【】乱码
	
	return $k;
	
}

/*根据科目里面每种题型导入题目
 *参数:	题目内容(不为空) 用户答案 参考答案 解析 选项个数 科目中题型编号 题目题型 题库里面所有科目和章节 科目号或章节号 试卷中大题 试卷中分数
 *返回:相关信息 成功数目 失败数目
 */
function import_question($idata,$userdaan,$daan,$jiexi,$opcount,$tixing_id,$questiontype_id,$subject_idlist,$subject_id,$part_id='',$fenshu='')
{
	global $newdb;

	$d='';
	$succ=0;
	$fail=0;
	$add=0;//新增题目
	$subAdd=0;//科目或章节新增

    //正则分割选项用
	$op_num_arr=array("[a,A]","[b,B]","[c,C]","[d,D]","[e,E]","[f,F]","[g,G]","[h,H]");
	
	//判断正误
	$op_num=array(
	     array('a','A'),
	     array('b','B'),
	     array('c','C'),
	     array('d','D'),
	     array('e','E'),
	     array('f','F'),
	     array('g','G'),
	     array('h','H')
	);
	
	//判断题
	$panduan_arr=array(
	     array('a','A',"正确","对","T","True","○","是","√","Y","yes"),
	     array('b','B',"错误","错","F","False","×","否","X","N","no")
	);
	
	//每个小题内切割通用正则
	$oregstr="/(.*?)";	

	switch ($questiontype_id)
	{
		    case 4://判断题录入时候不写选项,自动生成
		    case 9://填空
		    case 10://实务
		          break;

		    default:
			    for ($i=0;$i < $opcount;$i++)
		        {
			        $oregstr.=$op_num_arr[$i];
			        $oregstr.="(?:、|\.|．)(.*?)";
		        }
	}
       
	$flag=2;//小题切割分出答案解析序号
	if($userdaan)
	{
		$flag++;
		$split[]=$userdaan.'(.*?)';//用户答案
	}

	if ($daan)
		$split[]=$daan.'(.*?)';//参考答案
		
	if ($jiexi)
		$split[]=$jiexi.'(.*?)';//解析

	$regstr=$oregstr.implode($split)."$/is";//分隔正则表达式

	//echo $regstr."<br>";//小题切割通用副结束	
	$aidata=preg_split('/\d+(\.|、|．)(?![0-9])/',$idata);//切割出每个大题目
	
	//每个大题内部切割
	foreach ($aidata as $item=>$k)
	{
	  if($k)//不为空
	  {
		 $d.="<br>——>>>>>>【第".$item."个题目】<<<<<<——<br>";

		 $questa=preg_split('/###/',$k);//按###分隔为每个小题目###1>、(不是1、)

		 $quest=array();
		 $answer=array();
		 $question_text=array();
		 $question_newdemo=array();
		 $question_nodemo="";
		
		 if (count($questa)>1)
		 {//综合题特殊处理
			  $question_text[]=str_check($questa[0]);//大标题
			  $questa=array_slice($questa, 1); //依次取出每个小标题
			  $question_nodemo="暂无解析";//综合题占位
		 }
	
		 foreach ($questa as  $index => $l)//每个小标题
		 {
			 //切出选项
			 if (preg_match($regstr,$l,$a))
			 {
				  //print_r($a);
				  $questionText=str_check($a[1]);//小题目
				  $questionDemo=str_check($a[$flag+1]);//解析

				  switch ($questiontype_id)
				  {
					  case 4://判断
					       $question_text[]=$questionText;				
					       $answer[$index*2]['answer_text']="正确";
					       $answer[$index*2]['combine_id']=$index+1;
					       $answer[$index*2]['answer_id']=1;
					       $answer[$index*2]['is_true_answer']=0;
					       foreach ($panduan_arr[0] as $opk)
					       {
						        if (stristr($a[$flag],$opk))   
							        $answer[$index*2]['is_true_answer']=1;	//是否为正确答案
					       }
						   
					       $answer[$index*2+1]['answer_text']="错误";
					       $answer[$index*2+1]['combine_id']=$index+1;
					       $answer[$index*2+1]['answer_id']=2;
					       $answer[$index*2+1]['is_true_answer']=0;
					       foreach ($panduan_arr[1] as $opk)
					       {
						       if (stristr($a[$flag],$opk))   
							       $answer[$index*2+1]['is_true_answer']=1;	
					       }
					       $question_newdemo[]=$questionDemo?$questionDemo:$question_nodemo;
					  break;
					
					  case 9://填空
					  case 10://实务操作
					       $question_text[]=$questionText;	
						   if($questiontype_id==9)//填空
						   {
							   //不含空格
							   $answer[$index]['answer_text']=cloze_format($a[$flag]);
						   }
						   else
						   {
							   $answer[$index]['answer_text']=str_check($a[$flag]);//答案
						   }				     
					       $answer[$index]['combine_id']=$index+1;
					       $answer[$index]['answer_id']=1;
					       $answer[$index]['is_true_answer']=1;				
					       $question_newdemo[]=$questionDemo?$questionDemo:$question_nodemo;
					  break;
					
					  default:
						   //非填空题
					       $question_text[]=$questionText;//小标题
					       //分离选项						
					       for ($i=0;$i<$opcount;$i++)//分出选项并确定正确答案
			               {
			      	           $answer[$index*$opcount+$i]['answer_text']=str_check($a[2+$i]);
			      	           $answer[$index*$opcount+$i]['combine_id']=$index+1;	$answer[$index*$opcount+$i]['is_true_answer']=0;	
							   foreach ($op_num[$i] as $opk)
						       { 							 
							      if (stristr($a[$flag+$opcount],$opk))//编辑器致c,b判断成相同
							      {
								      $answer[$index*$opcount+$i]['is_true_answer']=1;	
							      }
						       }			
			                   $answer[$index*$opcount+$i]['answer_id']=$i+1;
			               }

					       $questionOpDemo=str_check($a[($flag+1)+$opcount]);//解析
					       $question_newdemo[]=$questionOpDemo?$questionOpDemo:$question_nodemo;
				    
				  }//switch
				
				  $succ++;
			 }//切出选项结束
			 else
			 {
				 $fail++;
				 $d.="<br>------>格式错误,导入失败：".$l."<------<br>";				 
			 }
	
		 }//每个小标题循环切割结束

		  //echo $d;
          //exit();

	  }//不为空
	}//大题结束

    $result='';//返回信息
	$result['info']='<br>********>本次总题库新增'.$add.'题,章节或科目(编号：'.$subject_id.')中新增'.$subAdd.'题<********<br>'.$d;
	$result['succ']=$succ;//成功数目
	$result['fail']=$fail;//失败数目

	return $result;
}

?>