<?php
set_time_limit(0);

$a=($_POST['question']);
$c=($_POST['answer']);

if (($a)&&($c))
{
	
	//echo $c;
	
	$a=preg_replace("/A、/", "A.",  $a);
	$a=preg_replace("/B、/", "B.",  $a);
	$a=preg_replace("/C、/", "C.",  $a);
	$a=preg_replace("/D、/", "D.",  $a);
	$a=preg_replace("/E、/", "E.",  $a);
	$a=preg_replace("/F、/", "F.",  $a);
	$a=preg_replace("/G、/", "G.",  $a);
	$a=preg_replace("/H、/", "H.",  $a);
	
	$b=preg_split('/\d+(\.|、|．)(?![0-9])/',$a);
	
	$d=preg_split('/\d+(\.|、|．)(?![0-9])/',$c);
	//$b=preg_split('/\d+[\.|、](?![0-9])/',$a);
	
	//print_r($b);
	//print_r($d);
	
	if (count($b)!=count($d))
	{
	echo "题目和答案数量不匹配"."<br>";
	$tc=count($b)-1;
	$ac=count($d)-1;
	echo "题目数量：".$tc."<br>";
	echo "答案数量：".$ac."<br>";
	echo "<pre>";
	print_r($b);
	echo "</pre><br><pre>";
	print_r($d);
	echo "</pre>";
  }
	else
	{
			for ($i=1;$i<count($b);$i++)
			{
				echo $i."、".$b[$i]."<br>答案：".$d[$i]."<br>";
			}
  }
}
elseif ($a)
{
	$a=preg_replace("/A、/", "A.",  $a);
	$a=preg_replace("/B、/", "B.",  $a);
	$a=preg_replace("/C、/", "C.",  $a);
	$a=preg_replace("/D、/", "D.",  $a);
	$a=preg_replace("/E、/", "E.",  $a);
	$a=preg_replace("/F、/", "F.",  $a);
	$a=preg_replace("/G、/", "G.",  $a);
	$a=preg_replace("/H、/", "H.",  $a);
	
	$a=preg_replace("/A．/", "A.",  $a);
	$a=preg_replace("/B．/", "B.",  $a);
	$a=preg_replace("/C．/", "C.",  $a);
	$a=preg_replace("/D．/", "D.",  $a);
	$a=preg_replace("/E．/", "E.",  $a);
	$a=preg_replace("/F．/", "F.",  $a);
	$a=preg_replace("/G．/", "G.",  $a);
	$a=preg_replace("/H．/", "H.",  $a);
	
	echo $a;
}

if ($a)
{
	$helpshow=0;
}
else
{
	$helpshow=1;
}

?>