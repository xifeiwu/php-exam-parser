<?php
require_once("questFunction.php");

header("Content-Type:text/html;charset=UTF-8");

$subject_id=($_GET['subject_id'])?$_GET['subject_id']:$_POST['subject_id'];
$part_id=($_GET['part_id'])?$_GET['part_id']:$_POST['part_id'];
$fenshu=($_GET['fenshu'])?$_GET['fenshu']:$_POST['fenshu'];

$idata=$_POST['data'];//题目内容
$daan=$_POST['daan'];//答案前缀
$jiexi=$_POST['jiexi'];//解析前缀
$opcount=$_POST['optioncount'];//选项个数
$tixing_id=$_POST['tixing_id'];//题型
if ($tixing_id)
{
	$questiontype_id=$tixing_arr['qtype_id'];
}

$d="";
$succ=0;
$fail=0;

if ($_GET['s'])
{
	$d=$_GET['s'];
}

if($idata)
{
	//普通题型,非图形表格类题目
	$idata=str_check($idata);
	//先替换再分割不容易出错,比如"格"被当初全角"Ａ"
	$daan=str_check($daan);//前缀
	$jiexi=str_check($jiexi);//前缀

	$result=import_question($idata,'',$daan,$jiexi,$opcount,$tixing_id,$questiontype_id,$subject_idlist,$subject_id,$part_id,$fenshu);
	$d=$result['info'];
	$succ=$result['succ'];
	$fail=$result['fail'];

}

?>